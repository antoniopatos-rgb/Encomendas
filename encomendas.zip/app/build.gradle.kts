plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.bmsolucoes.encomendas"
    compileSdk = 34

    defaultConfig {
        applicationId = "br.com.bmsolucoes.encomendas"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"
    }

    // Chave fixa de teste: assim cada APK novo instala por cima do anterior
    // sem apagar as encomendas já registradas.
    signingConfigs {
        create("teste") {
            storeFile = file("teste.keystore")
            storePassword = "bmsolucoes"
            keyAlias = "teste"
            keyPassword = "bmsolucoes"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("teste")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("teste")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    // Leitura de texto e código de barras no próprio celular (grátis, sem internet)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
}
