package br.com.bmsolucoes.encomendas

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.provider.Settings
import com.google.mlkit.vision.text.Text
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------------------
// Licença: 5 dias de teste e depois código de liberação por aparelho
// ---------------------------------------------------------------------------
object Licenca {
    const val DIAS_TESTE = 5
    // ATENÇÃO: este segredo é o mesmo da página geradora. Deixe o repositório PRIVADO.
    private const val SEGREDO = "BMS-App-7f3K9q2LxW-2026"
    private const val ALFABETO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private const val DIA = 86_400_000L

    private fun prefs(c: Context) = c.getSharedPreferences("licenca", Context.MODE_PRIVATE)

    fun limpar(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    private fun hash8(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (i in 0 until 8) sb.append(ALFABETO[d[i].toInt() and 31])
        return sb.toString()
    }

    private fun formatar(s: String) = s.substring(0, 4) + "-" + s.substring(4, 8)

    fun codigoAparelho(c: Context): String {
        val id = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "sem-id"
        return formatar(hash8("BMAPP|$id"))
    }

    private fun codigoLiberacao(codAparelho: String) = hash8(SEGREDO + "|" + limpar(codAparelho))

    fun liberado(c: Context): Boolean {
        val chave = prefs(c).getString("chave", null) ?: return false
        return limpar(chave) == codigoLiberacao(codigoAparelho(c))
    }

    fun tentarLiberar(c: Context, codigo: String): Boolean {
        val ok = limpar(codigo) == codigoLiberacao(codigoAparelho(c))
        if (ok) prefs(c).edit().putString("chave", limpar(codigo)).apply()
        return ok
    }

    fun diasRestantes(c: Context): Int {
        val p = prefs(c)
        val agora = System.currentTimeMillis()
        var inicio = p.getLong("inicio", 0L)
        if (inicio == 0L) {
            inicio = agora
            p.edit().putLong("inicio", agora).apply()
        }
        val ultimo = p.getLong("ultimo", 0L)
        if (agora > ultimo) p.edit().putLong("ultimo", agora).apply()
        // Relógio do celular voltado para trás: considera o teste encerrado.
        if (ultimo > 0L && agora < ultimo - 3_600_000L) return 0
        if (agora < inicio) return 0
        val usados = ((agora - inicio) / DIA).toInt()
        return (DIAS_TESTE - usados).coerceAtLeast(0)
    }

    fun bloqueado(c: Context): Boolean = !liberado(c) && diasRestantes(c) <= 0
}

// ---------------------------------------------------------------------------
// Leitura do quadro do destinatário na etiqueta
// ---------------------------------------------------------------------------
object Etiqueta {
    private fun ehCabecalho(n: String): Boolean =
        n.contains("destinat") || n.contains("receiver") || n.contains("recipient") ||
            n.contains("ship to") || n == "para" || n.startsWith("para ")

    private fun ehOutroQuadro(n: String): Boolean =
        n.contains("remetente") || n.contains("sender") || n.contains("devolu") || n.contains("endereco")

    /** Devolve a linha com o nome do destinatário, ou "" se não achar o quadro. */
    fun nomeDestinatario(t: Text): String {
        val linhas = t.textBlocks.flatMap { it.lines }
        val cab = linhas.firstOrNull { ehCabecalho(Texto.normalizar(it.text)) } ?: return ""

        // "Destinatário: FULANO DE TAL" na mesma linha
        val depois = cab.text.substringAfter(":", "").trim()
        if (depois.count { it.isLetter() } >= 4) return depois

        val caixa = cab.boundingBox ?: return ""
        val altura = maxOf(caixa.height(), 10)
        val abaixo = linhas.filter { l ->
            if (l === cab) return@filter false
            val b = l.boundingBox ?: return@filter false
            val n = Texto.normalizar(l.text)
            b.top >= caixa.top + altura / 2 &&
                b.top <= caixa.bottom + altura * 6 &&
                b.right > caixa.left && b.left < caixa.right &&
                n.isNotBlank() && !ehOutroQuadro(n) && !ehCabecalho(n)
        }.sortedBy { it.boundingBox?.top ?: 0 }
        return abaixo.firstOrNull { l -> l.text.count { it.isLetter() } >= 4 }?.text?.trim() ?: ""
    }
}

// ---------------------------------------------------------------------------
// Relatórios: PDF e planilha (CSV que abre no Excel)
// ---------------------------------------------------------------------------
object Relatorio {
    private val fData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
    private val fDataHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
    private val fArquivo = SimpleDateFormat("yyyyMMdd", Locale("pt", "BR"))

    fun inicioDoDia(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun somarDias(ms: Long, dias: Int): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        add(Calendar.DAY_OF_MONTH, dias)
    }.timeInMillis

    fun inicioDoMes(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = inicioDoDia(ms)
        set(Calendar.DAY_OF_MONTH, 1)
    }.timeInMillis

    /** Texto do período: fim é exclusivo (meia-noite do dia seguinte). */
    fun periodo(inicio: Long, fim: Long): String {
        val a = fData.format(Date(inicio))
        val b = fData.format(Date(fim - 1))
        return if (a == b) a else "$a a $b"
    }

    fun filtrar(lista: List<Encomenda>, inicio: Long, fim: Long) =
        lista.filter { it.recebidoEm in inicio until fim }.sortedBy { it.recebidoEm }

    private fun pasta(c: Context) = File(c.cacheDir, "relatorios").apply { mkdirs() }

    private fun nomeArquivo(inicio: Long, fim: Long, ext: String): String {
        val a = fArquivo.format(Date(inicio))
        val b = fArquivo.format(Date(fim - 1))
        return if (a == b) "relatorio_encomendas_$a.$ext" else "relatorio_encomendas_${a}_a_$b.$ext"
    }

    private fun status(e: Encomenda): String =
        if (e.entregue) "Entregue " + fDataHora.format(Date(e.entregueEm)) +
            (if (e.retiradoPor.isNotBlank()) " para ${e.retiradoPor}" else "")
        else "Aguardando retirada"

    fun gerarCsv(c: Context, itens: List<Encomenda>, inicio: Long, fim: Long): File {
        fun campo(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("﻿")
        sb.append(listOf("Recebida", "Morador", "Unidade", "Telefone", "Pacote", "Onde está", "Código",
            "Observação", "Aviso WhatsApp", "Situação", "Entregue em", "Retirado por")
            .joinToString(";") { campo(it) }).append("\r\n")
        for (e in itens) {
            sb.append(listOf(
                fDataHora.format(Date(e.recebidoEm)), e.nome, e.unidade, e.telefone, e.descricao(),
                e.local, e.rastreio, e.obs,
                if (e.avisadoEm > 0) fDataHora.format(Date(e.avisadoEm)) else "não enviado",
                if (e.entregue) "Entregue" else "Aguardando retirada",
                if (e.entregue) fDataHora.format(Date(e.entregueEm)) else "",
                e.retiradoPor
            ).joinToString(";") { campo(it) }).append("\r\n")
        }
        val f = File(pasta(c), nomeArquivo(inicio, fim, "csv"))
        f.writeText(sb.toString(), Charsets.UTF_8)
        return f
    }

    fun gerarPdf(c: Context, itens: List<Encomenda>, inicio: Long, fim: Long): File {
        val doc = PdfDocument()
        val largura = 595
        val alturaPag = 842
        val margem = 40f
        val util = largura - 2 * margem

        val titulo = Paint().apply { isAntiAlias = true; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; color = Color.parseColor("#1565C0") }
        val negrito = Paint().apply { isAntiAlias = true; textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; color = Color.parseColor("#1A2230") }
        val normal = Paint().apply { isAntiAlias = true; textSize = 10.5f; color = Color.parseColor("#33404F") }
        val suave = Paint().apply { isAntiAlias = true; textSize = 9.5f; color = Color.parseColor("#5B6576") }
        val linha = Paint().apply { color = Color.parseColor("#DDE2E8"); strokeWidth = 1f }

        var numPagina = 0
        var pagina: PdfDocument.Page? = null
        var y = 0f

        fun cortar(texto: String, p: Paint): String {
            val n = p.breakText(texto, true, util, null)
            return if (n >= texto.length) texto else texto.substring(0, maxOf(0, n - 1)) + "…"
        }

        fun novaPagina() {
            pagina?.let { doc.finishPage(it) }
            numPagina++
            pagina = doc.startPage(PdfDocument.PageInfo.Builder(largura, alturaPag, numPagina).create())
            y = margem + 10f
            pagina!!.canvas.drawText("Página $numPagina", largura - margem - 50f, alturaPag - 20f, suave)
        }

        fun escrever(texto: String, p: Paint, espaco: Float) {
            if (y + espaco > alturaPag - 50f) novaPagina()
            y += espaco
            pagina!!.canvas.drawText(cortar(texto, p), margem, y, p)
        }

        novaPagina()
        val entregues = itens.count { it.entregue }
        escrever("BM Soluções App · Relatório de encomendas", titulo, 8f)
        escrever("Período: " + periodo(inicio, fim), normal, 22f)
        escrever("Gerado em " + fDataHora.format(Date()), suave, 15f)
        escrever("Chegaram: ${itens.size}    Entregues: $entregues    Aguardando retirada: ${itens.size - entregues}", negrito, 24f)
        y += 10f
        pagina!!.canvas.drawLine(margem, y, largura - margem, y, linha)

        if (itens.isEmpty()) escrever("Nenhuma encomenda recebida neste período.", normal, 24f)

        for (e in itens) {
            if (y + 70f > alturaPag - 50f) novaPagina()
            val titulo1 = fDataHora.format(Date(e.recebidoEm)) + "  ·  " + e.nome +
                (if (e.unidade.isNotBlank()) " · ${e.unidade}" else "")
            escrever(titulo1, negrito, 20f)
            val det = listOf(e.descricao(), e.local, if (e.rastreio.isNotBlank()) "Cód.: ${e.rastreio}" else "")
                .filter { it.isNotBlank() }.joinToString("  ·  ")
            if (det.isNotBlank()) escrever(det, normal, 14f)
            escrever(status(e) + (if (e.obs.isNotBlank()) "  ·  Obs.: ${e.obs}" else ""), suave, 13f)
            y += 8f
            pagina!!.canvas.drawLine(margem, y, largura - margem, y, linha)
        }
        pagina?.let { doc.finishPage(it) }

        val f = File(pasta(c), nomeArquivo(inicio, fim, "pdf"))
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
