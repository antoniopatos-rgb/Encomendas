package br.com.bmsolucoes.encomendas

import android.content.Context
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer

// ---------------------------------------------------------------------------
// Encomenda registrada
// ---------------------------------------------------------------------------
data class Encomenda(
    val id: Long = 0L,
    var nome: String = "",
    var unidade: String = "",
    var telefone: String = "",
    var rastreio: String = "",
    var tipo: String = "",
    var tamanho: String = "",
    var cor: String = "",
    var local: String = "",
    var obs: String = "",
    var fotoEtiqueta: String = "",
    var fotoPacote: String = "",
    var recebidoEm: Long = 0L,
    var avisadoEm: Long = 0L,
    var entregueEm: Long = 0L,
    var retiradoPor: String = ""
) {
    val entregue: Boolean get() = entregueEm > 0L

    /** Ex.: "Caixa pequena preta" */
    fun descricao(): String {
        val feminino = tipo.equals("Caixa", true) || tipo.equals("Sacola", true)
        val partes = listOf(tipo, ajustar(tamanho, feminino), ajustar(cor, feminino))
            .filter { it.isNotBlank() }
        if (partes.isEmpty()) return ""
        return partes.joinToString(" ").lowercase().replaceFirstChar { it.uppercase() }
    }

    private fun ajustar(palavra: String, feminino: Boolean): String {
        val masculinas = setOf("pequeno", "médio", "preto", "branco", "pardo", "amarelo", "colorido")
        return if (feminino && palavra.lowercase() in masculinas) palavra.dropLast(1) + "a" else palavra
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("nome", nome); put("unidade", unidade); put("telefone", telefone)
        put("rastreio", rastreio); put("tipo", tipo); put("tamanho", tamanho); put("cor", cor)
        put("local", local); put("obs", obs); put("fotoEtiqueta", fotoEtiqueta)
        put("fotoPacote", fotoPacote); put("recebidoEm", recebidoEm); put("avisadoEm", avisadoEm)
        put("entregueEm", entregueEm); put("retiradoPor", retiradoPor)
    }

    companion object {
        fun fromJson(o: JSONObject) = Encomenda(
            id = o.optLong("id"),
            nome = o.optString("nome"),
            unidade = o.optString("unidade"),
            telefone = o.optString("telefone"),
            rastreio = o.optString("rastreio"),
            tipo = o.optString("tipo"),
            tamanho = o.optString("tamanho"),
            cor = o.optString("cor"),
            local = o.optString("local"),
            obs = o.optString("obs"),
            fotoEtiqueta = o.optString("fotoEtiqueta"),
            fotoPacote = o.optString("fotoPacote"),
            recebidoEm = o.optLong("recebidoEm"),
            avisadoEm = o.optLong("avisadoEm"),
            entregueEm = o.optLong("entregueEm"),
            retiradoPor = o.optString("retiradoPor")
        )
    }
}

// ---------------------------------------------------------------------------
// Armazenamento local (somente no celular)
// ---------------------------------------------------------------------------
object Banco {
    private fun arquivo(ctx: Context) = File(ctx.filesDir, "encomendas.json")

    fun carregar(ctx: Context): MutableList<Encomenda> {
        val f = arquivo(ctx)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            MutableList(arr.length()) { Encomenda.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun salvar(ctx: Context, lista: List<Encomenda>) {
        val arr = JSONArray()
        lista.forEach { arr.put(it.toJson()) }
        val conteudo = arr.toString()
        val tmp = File(ctx.filesDir, "encomendas.tmp")
        tmp.writeText(conteudo)
        if (!tmp.renameTo(arquivo(ctx))) {
            arquivo(ctx).writeText(conteudo)
            tmp.delete()
        }
    }
}

// ---------------------------------------------------------------------------
// Utilidades de texto
// ---------------------------------------------------------------------------
object Texto {
    private val acentos = Regex("\\p{M}+")
    private val naoAlfa = Regex("[^a-z0-9]+")

    /** "Antônio NÓBREGA" -> "antonio nobrega" */
    fun normalizar(s: String): String {
        val semAcento = Normalizer.normalize(s, Normalizer.Form.NFD).replace(acentos, "")
        return semAcento.lowercase().replace(naoAlfa, " ").trim()
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var anterior = IntArray(b.length + 1) { it }
        var atual = IntArray(b.length + 1)
        for (i in 1..a.length) {
            atual[0] = i
            for (j in 1..b.length) {
                val custo = if (a[i - 1] == b[j - 1]) 0 else 1
                atual[j] = minOf(atual[j - 1] + 1, anterior[j] + 1, anterior[j - 1] + custo)
            }
            val t = anterior; anterior = atual; atual = t
        }
        return anterior[b.length]
    }

    /** 1.0 = igual; 0.0 = totalmente diferente */
    fun similaridade(a: String, b: String): Double {
        if (a == b) return 1.0
        val maior = maxOf(a.length, b.length)
        if (maior == 0) return 1.0
        if (kotlin.math.abs(a.length - b.length) > 3) return 0.0
        return 1.0 - levenshtein(a, b).toDouble() / maior
    }

    /** Converte "(94) 99999-0000" em "5594999990000" para o WhatsApp */
    fun telefoneWhats(tel: String, dddPadrao: String = "94"): String {
        var d = tel.filter { it.isDigit() }.trimStart('0')
        if (d.length == 8 || d.length == 9) d = dddPadrao + d   // salvo sem DDD: usa 94 (Marabá)
        if (d.length == 10 || d.length == 11) d = "55$d"
        return d
    }
}

// ---------------------------------------------------------------------------
// Moradores lidos dos contatos do celular
// Padrão do contato: "Antônio Nóbrega casa 203" ou "Maria Silva bl B ap 104"
// ---------------------------------------------------------------------------
data class Morador(val nome: String, val unidade: String, val telefone: String, val nomeCompleto: String) {
    val tokens: List<String> = Texto.normalizar(nome).split(" ").filter { it.length >= 3 }
    val busca: String = Texto.normalizar("$nomeCompleto ${telefone.filter { it.isDigit() }}")
}

data class Sugestao(val morador: Morador, val pontos: Double)

object Moradores {
    private val regexUnidade = Regex(
        "\\b(casa|cs|apto|apt|ap|apartamento|bloco|bl|torre|lote|lt|quadra|qd|unidade|un)\\b",
        RegexOption.IGNORE_CASE
    )
    private val digitos = Regex("\\d+")

    fun carregar(ctx: Context): List<Morador> {
        val lista = mutableListOf<Morador>()
        val vistos = HashSet<String>()
        val colNome = "display_name"
        val colTel = ContactsContract.CommonDataKinds.Phone.NUMBER
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(colNome, colTel), null, null, "$colNome ASC"
        ) ?: return lista
        cursor.use { c ->
            val iNome = c.getColumnIndex(colNome)
            val iTel = c.getColumnIndex(colTel)
            if (iNome < 0 || iTel < 0) return lista
            while (c.moveToNext()) {
                val completo = c.getString(iNome)?.trim().orEmpty()
                val tel = c.getString(iTel)?.trim().orEmpty()
                if (completo.isEmpty() || tel.isEmpty()) continue
                val chave = completo.lowercase() + "|" + tel.filter { it.isDigit() }.takeLast(8)
                if (!vistos.add(chave)) continue
                val m = regexUnidade.find(completo)
                val nome = if (m != null) completo.substring(0, m.range.first).trim() else completo
                val unidade = if (m != null) completo.substring(m.range.first).trim() else ""
                lista.add(Morador(nome.ifBlank { completo }, unidade, tel, completo))
            }
        }
        return lista
    }

    /** Procura os moradores cujo nome aparece no texto da etiqueta (aceita erros de leitura). */
    fun sugerir(textoEtiqueta: String, moradores: List<Morador>, max: Int = 3): List<Sugestao> {
        val norm = Texto.normalizar(textoEtiqueta)
        if (norm.isBlank()) return emptyList()
        val todas = norm.split(" ")
        val palavras = todas.filter { it.length >= 3 && it.any(Char::isLetter) }.toSet()
        val numeros = todas.filter { it.any(Char::isDigit) }.toSet()
        if (palavras.isEmpty()) return emptyList()

        val resultado = moradores.mapNotNull { m ->
            if (m.tokens.isEmpty()) return@mapNotNull null
            var soma = 0.0
            var acertos = 0
            for (t in m.tokens) {
                var melhor = 0.0
                for (p in palavras) {
                    val s = Texto.similaridade(t, p)
                    if (s > melhor) melhor = s
                    if (melhor == 1.0) break
                }
                if (melhor >= 0.75) { soma += melhor; acertos++ }
            }
            if (acertos == 0) return@mapNotNull null
            var pontos = soma / m.tokens.size
            if (acertos >= 2) pontos += 0.2
            val numUnidade = digitos.findAll(m.unidade).map { it.value }.toList()
            if (numUnidade.isNotEmpty() && numUnidade.all { it in numeros }) pontos += 0.15
            if (pontos < 0.3) null else Sugestao(m, pontos)
        }
        return resultado.sortedByDescending { it.pontos }.take(max)
    }

    /** Busca manual: "203", "anto", "nobrega"... */
    fun buscar(consulta: String, moradores: List<Morador>, max: Int = 8): List<Morador> {
        val q = Texto.normalizar(consulta)
        if (q.length < 2) return emptyList()
        val partes = q.split(" ")
        return moradores.filter { m -> partes.all { m.busca.contains(it) } }.take(max)
    }
}

// ---------------------------------------------------------------------------
// Código de rastreio (Correios, AliExpress, Shopee etc.)
// ---------------------------------------------------------------------------
object Rastreio {
    private val padraoCorreios = Regex("[A-Z]{2}\\d{9}[A-Z]{2}")
    private val padraoTexto = Regex("\\b[A-Z]{2}\\s?\\d{9}\\s?[A-Z]{2}\\b")
    private val generico = Regex("[A-Z0-9-]{10,35}")

    fun escolher(codigos: List<String>, texto: String): String {
        val limpos = codigos.map { it.trim().uppercase().replace(" ", "") }
        limpos.firstOrNull { padraoCorreios.matches(it) }?.let { return it }
        padraoTexto.find(texto.uppercase())?.let { return it.value.replace(" ", "") }
        limpos.firstOrNull { generico.matches(it) && it.any(Char::isLetter) }?.let { return it }
        limpos.firstOrNull { generico.matches(it) }?.let { return it }
        return ""
    }
}
