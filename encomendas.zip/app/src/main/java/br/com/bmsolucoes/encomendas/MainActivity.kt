package br.com.bmsolucoes.encomendas

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        private const val REQ_ETIQUETA = 10
        private const val REQ_PACOTE = 11
        private const val REQ_CONTATOS = 20

        private val AZUL = Color.parseColor("#1565C0")
        private val AZUL_CLARO = Color.parseColor("#E3ECF8")
        private val VERDE = Color.parseColor("#2E7D32")
        private val VERDE_CLARO = Color.parseColor("#E8F5E9")
        private val VERMELHO = Color.parseColor("#C62828")
        private val LARANJA = Color.parseColor("#A1460B")
        private val FUNDO = Color.parseColor("#F2F4F7")
        private val CINZA = Color.parseColor("#E6EAF0")
        private val BORDA = Color.parseColor("#C9D1DC")
        private val TEXTO = Color.parseColor("#1A2230")
        private val SUAVE = Color.parseColor("#5B6576")

        private val TIPOS = listOf("Caixa", "Envelope", "Pacote", "Saco plástico", "Sacola", "Outro")
        private val TAMANHOS = listOf("Pequeno", "Médio", "Grande")
        private val CORES = listOf("Preto", "Branco", "Marrom", "Cinza", "Azul", "Amarelo", "Colorido")
        private val LOCAIS = listOf("Prateleira 1", "Prateleira 2", "Prateleira 3", "Chão", "Armário")

        private const val FRASE_PADRAO = "Já está disponível para retirada na administração."
    }

    private var tela = "inicio"
    private var encomendas = mutableListOf<Encomenda>()
    private var moradores = listOf<Morador>()
    private var rascunho: Encomenda? = null
    private var textoEtiqueta = ""
    private var nomeLido = ""
    private var fotoPendente: String? = null
    private var detalheId = 0L
    private var mostrarEntregues = false
    private var mostrarAtrasadas = false
    private var mostrarSemDestino = false
    private var relInicio = 0L
    private var relFim = 0L
    private val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

    private var campoRastreio: EditText? = null
    private var campoObs: EditText? = null
    private var campoEmNome: EditText? = null
    private var lembrarEncaminhamento = true

    // =======================================================================
    // Ciclo de vida
    // =======================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        encomendas = Banco.carregar(this)
        if (savedInstanceState != null) {
            tela = savedInstanceState.getString("tela") ?: "inicio"
            fotoPendente = savedInstanceState.getString("fotoPendente")
            textoEtiqueta = savedInstanceState.getString("textoEtiqueta") ?: ""
            nomeLido = savedInstanceState.getString("nomeLido") ?: ""
            detalheId = savedInstanceState.getLong("detalheId")
            mostrarEntregues = savedInstanceState.getBoolean("mostrarEntregues")
            mostrarAtrasadas = savedInstanceState.getBoolean("mostrarAtrasadas")
            mostrarSemDestino = savedInstanceState.getBoolean("mostrarSemDestino")
            relInicio = savedInstanceState.getLong("relInicio")
            relFim = savedInstanceState.getLong("relFim")
            savedInstanceState.getString("rascunho")?.let {
                rascunho = try { Encomenda.fromJson(JSONObject(it)) } catch (e: Exception) { null }
            }
        }
        carregarMoradores()
        if (!temPermissaoContatos()) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTATOS)
        }
        mostrarTelaAtual()
    }

    override fun onResume() {
        super.onResume()
        if (Licenca.bloqueado(this) && tela != "ativar") telaAtivar()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        lerCampos()
        outState.putString("tela", tela)
        outState.putString("fotoPendente", fotoPendente)
        outState.putString("textoEtiqueta", textoEtiqueta)
        outState.putString("nomeLido", nomeLido)
        outState.putLong("detalheId", detalheId)
        outState.putBoolean("mostrarEntregues", mostrarEntregues)
        outState.putBoolean("mostrarAtrasadas", mostrarAtrasadas)
        outState.putBoolean("mostrarSemDestino", mostrarSemDestino)
        outState.putLong("relInicio", relInicio)
        outState.putLong("relFim", relFim)
        rascunho?.let { outState.putString("rascunho", it.toJson().toString()) }
        super.onSaveInstanceState(outState)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CONTATOS) {
            carregarMoradores()
            if (tela == "inicio") telaInicio()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (tela) {
            "nova" -> descartar()
            "detalhe", "config", "relatorios" -> telaInicio()
            "ativar" -> if (Licenca.bloqueado(this)) finish() else telaInicio()
            else -> super.onBackPressed()
        }
    }

    private fun mostrarTelaAtual() {
        if (Licenca.bloqueado(this)) { telaAtivar(); return }
        when (tela) {
            "nova" -> if (rascunho != null) telaNova() else telaInicio()
            "detalhe" -> encomendas.find { it.id == detalheId }?.let { telaDetalhe(it) } ?: telaInicio()
            "config" -> telaConfig()
            "relatorios" -> telaRelatorios()
            "ativar" -> telaAtivar()
            else -> telaInicio()
        }
    }

    private fun temPermissaoContatos() =
        checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun carregarMoradores() {
        moradores = if (temPermissaoContatos()) {
            try { Moradores.carregar(this) } catch (e: Exception) { emptyList() }
        } else emptyList()
    }

    // =======================================================================
    // Tela inicial (modelo cabeçalho azul)
    // =======================================================================
    private fun telaInicio() {
        tela = "inicio"
        campoRastreio = null
        campoObs = null
        campoEmNome = null
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(FUNDO) }
        val raiz = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(40)) }
        scroll.addView(raiz)

        // ---- Cabeçalho azul
        val cab = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(64))
            background = GradientDrawable().apply {
                setColor(AZUL)
                val r = dp(28).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        val linhaCab = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "BM"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(AZUL)
            gravity = Gravity.CENTER
            background = fundo(Color.WHITE, 12)
        }
        linhaCab.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) })
        val titulos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titulos.addView(texto("BM Soluções App", 20f, Color.WHITE, true))
        val infoContatos = if (!temPermissaoContatos()) "Encomendas · sem acesso aos contatos"
        else "Encomendas · ${moradores.size} contatos"
        titulos.addView(texto(infoContatos, 13f, Color.parseColor("#DCE7F7")))
        linhaCab.addView(titulos, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val atualizar = Button(this).apply {
            text = "⟳"
            textSize = 20f
            setTextColor(Color.WHITE)
            contentDescription = "Atualizar contatos"
            background = fundo(Color.parseColor("#33FFFFFF"), 12)
            setOnClickListener {
                if (!temPermissaoContatos()) {
                    requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTATOS)
                } else {
                    carregarMoradores(); telaInicio(); aviso("${moradores.size} contatos carregados")
                }
            }
        }
        linhaCab.addView(atualizar, LinearLayout.LayoutParams(dp(48), dp(48)))
        cab.addView(linhaCab)

        if (!Licenca.liberado(this)) {
            val dias = Licenca.diasRestantes(this)
            val faixa = texto("Versão de teste · faltam $dias ${if (dias == 1) "dia" else "dias"} · Ativar", 13f, Color.WHITE, true).apply {
                background = fundo(Color.parseColor("#33FFFFFF"), 20)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { telaAtivar() }
            }
            cab.addView(faixa, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) })
        }
        raiz.addView(cab)

        // ---- Contadores (também funcionam como abas)
        val inicioHoje = Relatorio.inicioDoDia(System.currentTimeMillis())
        val aguardando = encomendas.count { !it.entregue }
        val entreguesHoje = encomendas.count { it.entregue && it.entregueEm >= inicioHoje }
        val contadores = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        contadores.addView(contador("$aguardando", "Aguardando retirada", AZUL, !mostrarEntregues && !mostrarAtrasadas) {
            mostrarEntregues = false; mostrarAtrasadas = false; mostrarSemDestino = false; telaInicio()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(12) })
        contadores.addView(contador("$entreguesHoje", "Entregues hoje", VERDE, mostrarEntregues) {
            mostrarEntregues = true; mostrarAtrasadas = false; mostrarSemDestino = false; telaInicio()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        raiz.addView(contadores, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = -dp(44); leftMargin = dp(20); rightMargin = dp(20) })

        // ---- Corpo
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0) }
        raiz.addView(col)

        // ---- Alerta: encomendas sem destinatário
        val semDestino = encomendas.count { it.semDestino && !it.entregue }
        if (semDestino > 0) {
            val alertaSd = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(Color.parseColor("#ECEFF3"), 14, SUAVE).apply {
                    if (mostrarSemDestino) setStroke(dp(2), TEXTO)
                }
                setPadding(dp(16), dp(12), dp(16), dp(12))
                isClickable = true
                setOnClickListener { mostrarSemDestino = true; mostrarAtrasadas = false; mostrarEntregues = false; telaInicio() }
            }
            val plural = if (semDestino == 1) "encomenda sem destinatário" else "encomendas sem destinatário"
            alertaSd.addView(texto("❓ $semDestino $plural", 16f, TEXTO, true))
            alertaSd.addView(texto("Toque para ver, definir o morador ou registrar a devolução", 14f, SUAVE))
            col.poe(alertaSd, 14)
        }

        // ---- Alerta: encomendas há 7 dias ou mais
        val atrasadas = encomendas.filter { it.atrasada() }
        if (atrasadas.isNotEmpty()) {
            val semLembrete = atrasadas.count { it.semLembrete() }
            val alerta = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(Color.parseColor("#FFF3E0"), 14, LARANJA).apply {
                    if (mostrarAtrasadas) setStroke(dp(2), LARANJA)
                }
                setPadding(dp(16), dp(12), dp(16), dp(12))
                isClickable = true
                setOnClickListener { mostrarAtrasadas = true; mostrarEntregues = false; mostrarSemDestino = false; telaInicio() }
            }
            val plural = if (atrasadas.size == 1) "encomenda aguardando" else "encomendas aguardando"
            alerta.addView(texto("⚠ ${atrasadas.size} $plural há 7 dias ou mais", 16f, LARANJA, true))
            alerta.addView(texto(
                if (semLembrete > 0) "$semLembrete sem lembrete · toque para ver e reenviar o aviso"
                else "Todas já receberam lembrete · toque para ver", 14f, Color.parseColor("#6D3A0A")))
            col.poe(alerta, 14)
        }

        col.poe(botao("📷  Nova encomenda", VERDE) { abrirCamera(REQ_ETIQUETA) }.apply {
            textSize = 19f; minHeight = dp(68); setTypeface(null, Typeface.BOLD)
        }, 14)

        val atalhos = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        atalhos.addView(botao("📊 Relatórios", Color.WHITE, TEXTO) { relInicio = 0L; telaRelatorios() }.apply {
            textSize = 15f; background = fundo(Color.WHITE, 12, BORDA)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(10) })
        atalhos.addView(botao("⚙ Mensagem", Color.WHITE, TEXTO) { telaConfig() }.apply {
            textSize = 15f; background = fundo(Color.WHITE, 12, BORDA)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.poe(atalhos, 10)

        val busca = campo("🔍 Buscar por nome, casa ou código")
        col.poe(busca, 14)
        val tituloLista = when {
            mostrarSemDestino -> "Sem destinatário"
            mostrarAtrasadas -> "Há 7 dias ou mais · reenvie o aviso"
            mostrarEntregues -> "Entregues (mais recentes)"
            else -> "Aguardando retirada"
        }
        col.poe(texto(tituloLista, 15f, if (mostrarAtrasadas) LARANJA else Color.parseColor("#33404F"), true), 16)
        val lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.poe(lista, 2)

        fun mostrarLista(consulta: String) {
            lista.removeAllViews()
            val q = Texto.normalizar(consulta)
            val base = when {
                mostrarSemDestino -> encomendas.filter { it.semDestino && !it.entregue }.sortedByDescending { it.recebidoEm }
                mostrarAtrasadas -> encomendas.filter { it.atrasada() }.sortedBy { it.recebidoEm }
                mostrarEntregues -> encomendas.filter { it.entregue }.sortedByDescending { it.entregueEm }
                else -> encomendas.filter { !it.entregue }.sortedByDescending { it.recebidoEm }
            }
            val itens = base
                .filter { q.isEmpty() || Texto.normalizar("${it.nome} ${it.unidade} ${it.rastreio} ${it.descricao()} ${it.obs} ${it.emNomeDe}").contains(q) }
                .take(200)
            if (itens.isEmpty()) lista.poe(texto("Nenhuma encomenda aqui.", 15f, SUAVE), 12)
            itens.forEach { enc ->
                lista.poe(cartao(enc), 10)
                if (mostrarAtrasadas && enc.telefone.isNotBlank()) {
                    lista.poe(botao(
                        if (enc.semLembrete()) "🔔 Reenviar aviso para ${enc.nome.split(" ").first()}"
                        else "🔔 Reenviar de novo (último: ${formato.format(Date(enc.lembreteEm))})",
                        Color.parseColor("#FFF3E0"), Color.parseColor("#6D3A0A")
                    ) { enviarLembrete(enc); telaInicio() }.apply { textSize = 15f; minHeight = dp(46) }, 4)
                }
            }
        }
        aoDigitar(busca) { mostrarLista(it) }
        mostrarLista("")
        setContentView(scroll)
    }

    private fun contador(numero: String, rotulo: String, cor: Int, ativo: Boolean, acao: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fundo(Color.WHITE, 16, if (ativo) cor else null).apply {
                if (ativo) setStroke(dp(2), cor)
            }
            elevation = dp(3).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            setOnClickListener { acao() }
        }
        c.addView(texto(numero, 30f, cor, true))
        c.addView(texto(rotulo, 14f, SUAVE))
        return c
    }

    private fun cartao(e: Encomenda): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = fundo(Color.WHITE, 14)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { telaDetalhe(e) }
        }
        val num = if (e.semDestino) "?" else Regex("\\d+").find(e.unidade)?.value ?: e.nome.take(1).uppercase()
        val selo = TextView(this).apply {
            text = num
            textSize = if (num.length > 3) 12f else 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(AZUL)
            gravity = Gravity.CENTER
            background = fundo(AZUL_CLARO, 12)
        }
        c.addView(selo, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(texto(e.nome, 16f, TEXTO, true))
        val desc = listOf(e.unidade, e.descricao(), e.local).filter { it.isNotBlank() }.joinToString(" · ")
        if (desc.isNotBlank()) col.addView(texto(desc, 14f, SUAVE))
        val (status, corStatus) = if (e.entregue) {
            ("✅ Entregue " + formato.format(Date(e.entregueEm)) +
                (if (e.retiradoPor.isNotBlank()) " para ${e.retiradoPor}" else "")) to VERDE
        } else if (e.semDestino) {
            ("Recebida " + formato.format(Date(e.recebidoEm)) + " · ❓ sem destinatário") to SUAVE
        } else if (e.atrasada()) {
            ("⚠ Aguardando há ${e.diasAguardando()} dias" +
                (if (e.lembreteEm > 0) " · lembrete " + formato.format(Date(e.lembreteEm)) else " · sem lembrete")) to LARANJA
        } else if (e.avisadoEm > 0) {
            ("Recebida " + formato.format(Date(e.recebidoEm)) + " · 📲 avisado") to SUAVE
        } else {
            ("Recebida " + formato.format(Date(e.recebidoEm)) + " · ⚠ não avisado") to LARANJA
        }
        col.addView(texto(status, 13f, corStatus))
        c.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return c
    }

    // =======================================================================
    // Câmera
    // =======================================================================
    private fun abrirCamera(req: Int) {
        if (Licenca.bloqueado(this)) { telaAtivar(); return }
        val pasta = File(filesDir, "fotos").apply { mkdirs() }
        val prefixo = if (req == REQ_ETIQUETA) "etiqueta_" else "pacote_"
        val arq = File(pasta, prefixo + System.currentTimeMillis() + ".jpg")
        fotoPendente = arq.absolutePath
        val uri = FileProvider.getUriForFile(this, "$packageName.fotos", arq)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            clipData = ClipData.newRawUri("foto", uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, req)
        } catch (e: ActivityNotFoundException) {
            fotoPendente = null
            aviso("Não encontrei o app de câmera.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_ETIQUETA && requestCode != REQ_PACOTE) return
        val caminho = fotoPendente
        fotoPendente = null
        val ok = resultCode == RESULT_OK && caminho != null && File(caminho).length() > 0
        if (!ok || caminho == null) {
            caminho?.let { File(it).delete() }
            if (requestCode == REQ_ETIQUETA) telaInicio() else if (rascunho != null) telaNova() else telaInicio()
            return
        }
        if (requestCode == REQ_ETIQUETA) {
            rascunho = Encomenda(fotoEtiqueta = caminho, recebidoEm = System.currentTimeMillis())
            textoEtiqueta = ""
            nomeLido = ""
            lembrarEncaminhamento = true
            processarEtiqueta(caminho)
        } else {
            val r = rascunho
            if (r == null) { File(caminho).delete(); telaInicio(); return }
            comprimirFoto(caminho, 1280)
            if (r.fotoPacote.isNotBlank()) File(r.fotoPacote).delete()
            r.fotoPacote = caminho
            telaNova()
        }
    }

    // =======================================================================
    // Leitura da etiqueta (texto + código de barras), tudo no celular
    // =======================================================================
    private fun processarEtiqueta(caminho: String) {
        tela = "nova"
        val col = novaPagina("Lendo etiqueta…", false)
        imagem(caminho, 260)?.let { col.poe(it, 12) }
        col.poe(ProgressBar(this), 20)
        col.poe(texto("Aguarde, lendo o nome e o código…", 15f, SUAVE).apply { gravity = Gravity.CENTER }, 8)

        // Lê em resolução maior (fontes pequenas e pontilhadas) e só depois reduz a foto.
        val bmp = carregarFoto(caminho, 1500)
        if (bmp == null) {
            aviso("Não consegui abrir a foto.")
            telaNova()
            return
        }
        val img = InputImage.fromBitmap(bmp, 0)
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
            .addOnCompleteListener { t ->
                if (t.isSuccessful) {
                    val resultado = t.result
                    if (resultado != null) {
                        textoEtiqueta = resultado.text
                        nomeLido = try { Etiqueta.nomeDestinatario(resultado) } catch (e: Exception) { "" }
                    }
                }
                BarcodeScanning.getClient().process(img)
                    .addOnCompleteListener { b ->
                        val codigos = if (b.isSuccessful) b.result?.mapNotNull { it.rawValue } ?: emptyList() else emptyList()
                        rascunho?.rastreio = Rastreio.escolher(codigos, textoEtiqueta)
                        comprimirFoto(caminho, 1800)
                        if (!isFinishing && tela == "nova") telaNova()
                    }
            }
    }

    // =======================================================================
    // Tela de nova encomenda
    // =======================================================================
    private fun telaNova() {
        val r = rascunho ?: return telaInicio()
        tela = "nova"
        val col = novaPagina("Nova encomenda", true)
        imagem(r.fotoEtiqueta, 180)?.let { col.poe(it, 12) }

        // ---- Morador
        col.poe(texto("Morador", 18f, TEXTO, true), 16)
        if (r.semDestino) {
            val caixa = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(Color.parseColor("#ECEFF3"), 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            caixa.addView(texto("❓ Sem destinatário", 18f, TEXTO, true))
            caixa.addView(texto("Fica registrada no recebimento. Depois dá para definir o morador ou registrar a devolução.", 14f, SUAVE))
            col.poe(caixa, 6)
            col.poe(botao("Escolher um morador", CINZA, TEXTO) {
                lerCampos(); r.semDestino = false; r.nome = ""; telaNova()
            }, 6)
        } else if (r.nome.isNotBlank()) {
            val caixa = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(VERDE_CLARO, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            caixa.addView(texto("✔ ${r.nome}", 18f, VERDE, true))
            if (r.unidade.isNotBlank()) caixa.addView(texto(r.unidade, 16f))
            caixa.addView(texto(if (r.telefone.isNotBlank()) "WhatsApp: ${r.telefone}" else "⚠ Contato sem telefone", 14f, SUAVE))
            col.poe(caixa, 6)
            col.poe(botao("Trocar morador", CINZA, TEXTO) {
                lerCampos(); r.nome = ""; r.unidade = ""; r.telefone = ""; r.emNomeDe = ""; telaNova()
            }, 6)

            col.poe(texto("Veio no nome de outra pessoa? (opcional)", 15f, TEXTO, true), 14)
            campoEmNome = campo("Ex.: João Silva (esposo)", r.emNomeDe).also { col.poe(it, 6) }
            val lembrar = android.widget.CheckBox(this).apply {
                text = "Lembrar: próximas encomendas nesse nome vão para ${r.nome.split(" ").first()}"
                textSize = 14f
                setTextColor(TEXTO)
                isChecked = lembrarEncaminhamento
                setOnCheckedChangeListener { _, marcado -> lembrarEncaminhamento = marcado }
            }
            col.poe(lembrar, 4)
        } else {
            if (nomeLido.isNotBlank()) {
                col.poe(texto("Nome lido na etiqueta: $nomeLido", 14f, AZUL, true).apply {
                    background = fundo(AZUL_CLARO, 10)
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }, 4)
            }
            val encaminhamento = Moradores.encaminhamentoPara(nomeLido, textoEtiqueta, Encaminhamentos.carregar(this))
            if (encaminhamento != null) {
                col.poe(texto("Encaminhamento salvo:", 14f, SUAVE), 8)
                col.poe(botaoEncaminhamento(encaminhamento), 6)
            }
            val sugestoes = Moradores.sugerir(nomeLido, textoEtiqueta, moradores)
            if (sugestoes.isNotEmpty()) {
                col.poe(texto("Sugestões (toque no certo):", 14f, SUAVE), 8)
                sugestoes.forEach { col.poe(botaoMorador(it.morador), 6) }
            } else {
                val msg = if (moradores.isEmpty())
                    "⚠ Nenhum contato carregado. Cadastre os moradores nos contatos do celular."
                else "Não encontrei esse morador nos contatos. Busque abaixo:"
                col.poe(texto(msg, 14f, SUAVE), 8)
            }
            val busca = campo("Buscar por nome ou nº da casa")
            col.poe(busca, 10)
            val resultados = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.poe(resultados, 2)
            col.poe(botao("❓ Sem destinatário (sem nome/endereço)", Color.WHITE, TEXTO) {
                lerCampos(); r.semDestino = true; r.nome = "Sem destinatário"; r.unidade = ""; r.telefone = ""; r.emNomeDe = ""
                telaNova()
            }.apply { background = fundo(Color.WHITE, 12, BORDA); textSize = 15f }, 12)
            aoDigitar(busca) { q ->
                resultados.removeAllViews()
                val nq = Texto.normalizar(q)
                if (nq.length >= 2) {
                    Encaminhamentos.carregar(this)
                        .filter { Texto.normalizar(it.nomeEtiqueta).contains(nq) }
                        .take(3)
                        .forEach { resultados.poe(botaoEncaminhamento(it), 6) }
                }
                Moradores.buscar(q, moradores).forEach { resultados.poe(botaoMorador(it), 6) }
            }
        }

        // ---- Código de rastreio
        col.poe(texto("Código de rastreio", 16f, TEXTO, true), 20)
        campoRastreio = campo("Ex.: LP123456789CN", r.rastreio,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS).also { col.poe(it, 6) }

        // ---- Descrição do pacote
        col.poe(linhaOpcoes("Tipo", TIPOS, r.tipo) { r.tipo = it }, 16)
        col.poe(linhaOpcoes("Tamanho", TAMANHOS, r.tamanho) { r.tamanho = it }, 12)
        col.poe(linhaOpcoes("Cor", CORES, r.cor) { r.cor = it }, 12)
        col.poe(linhaOpcoes("Onde guardou", LOCAIS, r.local) { r.local = it }, 12)

        col.poe(texto("Observação", 16f, TEXTO, true), 16)
        campoObs = campo("Ex.: frágil, 2 volumes", r.obs,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).also { col.poe(it, 6) }

        // ---- Foto do pacote
        col.poe(texto("Foto do pacote (opcional)", 16f, TEXTO, true), 16)
        if (r.fotoPacote.isNotBlank()) imagem(r.fotoPacote, 180)?.let { col.poe(it, 6) }
        col.poe(botao(if (r.fotoPacote.isBlank()) "📷 Tirar foto do pacote" else "📷 Refazer foto do pacote", CINZA, TEXTO) {
            lerCampos(); abrirCamera(REQ_PACOTE)
        }, 6)

        // ---- Ações
        if (r.semDestino) {
            col.poe(botao("✅ Salvar (sem destinatário)", AZUL) { salvar(false) }, 24)
        } else {
            col.poe(botao("✅ Salvar e avisar no WhatsApp", VERDE) { salvar(true) }, 24)
            col.poe(botao("Salvar sem avisar", AZUL) { salvar(false) }, 8)
        }
        col.poe(botao("Cancelar", CINZA, VERMELHO) { descartar() }, 8)
    }

    private fun botaoMorador(m: Morador): Button {
        val rotulo = if (m.unidade.isNotBlank()) "${m.nome} · ${m.unidade}" else m.nome
        return botao(rotulo, Color.WHITE, TEXTO) {
            lerCampos()
            rascunho?.let { r ->
                r.nome = m.nome; r.unidade = m.unidade; r.telefone = m.telefone
                // Etiqueta em nome de outra pessoa? Já preenche "Em nome de".
                if (r.emNomeDe.isBlank() && nomeLido.isNotBlank() && !Moradores.nomeCombina(nomeLido, m)) {
                    r.emNomeDe = nomeLido.lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
                    lembrarEncaminhamento = true
                }
            }
            telaNova()
        }.apply {
            background = fundo(Color.WHITE, 12, BORDA)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }
    }

    private fun botaoEncaminhamento(enc: Encaminhamento): Button {
        val destino = if (enc.unidade.isNotBlank()) "${enc.nome} · ${enc.unidade}" else enc.nome
        return botao("↪ ${enc.nomeEtiqueta}  →  $destino", VERDE_CLARO, VERDE) {
            lerCampos()
            rascunho?.let { r ->
                r.nome = enc.nome; r.unidade = enc.unidade; r.telefone = enc.telefone
                r.emNomeDe = enc.nomeEtiqueta
                lembrarEncaminhamento = true
            }
            telaNova()
        }.apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            textSize = 15f
        }
    }

    private fun lerCampos() {
        if (tela != "nova") return
        val r = rascunho ?: return
        campoRastreio?.let { r.rastreio = it.text.toString().trim().uppercase() }
        campoObs?.let { r.obs = it.text.toString().trim() }
        campoEmNome?.let { r.emNomeDe = it.text.toString().trim() }
    }

    private fun salvar(avisar: Boolean) {
        lerCampos()
        val r = rascunho ?: return
        if (r.nome.isBlank()) { aviso("Escolha o morador primeiro."); return }
        if (avisar && r.telefone.isBlank()) { aviso("Esse contato não tem telefone."); return }
        if (r.emNomeDe.isNotBlank() && lembrarEncaminhamento) Encaminhamentos.lembrar(this, r.emNomeDe, r)
        val agora = System.currentTimeMillis()
        val e = r.copy(id = agora)
        if (avisar) e.avisadoEm = agora
        encomendas.add(e)
        Banco.salvar(this, encomendas)
        rascunho = null
        textoEtiqueta = ""
        nomeLido = ""
        mostrarEntregues = false
        mostrarAtrasadas = false
        mostrarSemDestino = false
        telaInicio()
        aviso("Encomenda registrada.")
        if (avisar) enviarWhats(e)
    }

    private fun descartar() {
        AlertDialog.Builder(this)
            .setTitle("Descartar esta encomenda?")
            .setMessage("As fotos e os dados preenchidos serão apagados.")
            .setPositiveButton("Descartar") { _, _ ->
                rascunho?.let { r ->
                    if (r.fotoEtiqueta.isNotBlank()) File(r.fotoEtiqueta).delete()
                    if (r.fotoPacote.isNotBlank()) File(r.fotoPacote).delete()
                }
                rascunho = null
                textoEtiqueta = ""
                nomeLido = ""
                telaInicio()
            }
            .setNegativeButton("Continuar", null)
            .show()
    }

    // =======================================================================
    // Detalhe / entrega
    // =======================================================================
    private fun telaDetalhe(e: Encomenda) {
        tela = "detalhe"
        detalheId = e.id
        val col = novaPagina("Encomenda", true)
        col.poe(texto(e.nome, 22f, TEXTO, true), 12)
        if (e.unidade.isNotBlank()) col.poe(texto(e.unidade, 17f), 2)

        val infos = listOf(
            "Em nome de" to e.emNomeDe,
            "Pacote" to e.descricao(),
            "Onde está" to e.local,
            "Código" to e.rastreio,
            "Obs." to e.obs,
            "Recebida" to formato.format(Date(e.recebidoEm)),
            "Aviso no WhatsApp" to (if (e.avisadoEm > 0) formato.format(Date(e.avisadoEm)) else "não enviado")
        )
        infos.filter { it.second.isNotBlank() }.forEach { (k, v) -> col.poe(texto("$k: $v", 16f), 6) }

        if (e.entregue) {
            val caixa = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(VERDE_CLARO, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            caixa.addView(texto("✅ Entregue em ${formato.format(Date(e.entregueEm))}", 16f, VERDE, true))
            if (e.retiradoPor.isNotBlank()) caixa.addView(texto("Retirado por: ${e.retiradoPor}", 15f))
            if (e.assinatura.isNotBlank()) {
                caixa.addView(texto("Assinatura:", 14f, SUAVE).apply { setPadding(0, dp(8), 0, dp(4)) })
                val bmpAss = BitmapFactory.decodeFile(e.assinatura)
                if (bmpAss != null) {
                    caixa.addView(ImageView(this).apply {
                        setImageBitmap(bmpAss)
                        adjustViewBounds = true
                        maxHeight = dp(140)
                        scaleType = ImageView.ScaleType.FIT_START
                        background = fundo(Color.WHITE, 8)
                        contentDescription = "Assinatura de quem retirou"
                    })
                }
            } else {
                caixa.addView(texto("Sem assinatura", 14f, SUAVE))
            }
            col.poe(caixa, 14)
        }

        if (e.fotoPacote.isNotBlank()) {
            col.poe(texto("Foto do pacote", 15f, SUAVE), 16)
            imagem(e.fotoPacote, 260)?.let { col.poe(it, 4) }
        }
        if (e.fotoEtiqueta.isNotBlank()) {
            col.poe(texto("Foto da etiqueta", 15f, SUAVE), 16)
            imagem(e.fotoEtiqueta, 260)?.let { col.poe(it, 4) }
        }

        if (!e.entregue) {
            if (e.semDestino) {
                col.poe(texto("Definir o morador", 18f, TEXTO, true), 24)
                col.poe(texto("Se descobrir de quem é, busque e toque no morador. Depois é só avisar no WhatsApp.", 14f, SUAVE), 4)
                val buscaMor = campo("Buscar por nome ou nº da casa")
                col.poe(buscaMor, 8)
                val resMor = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                col.poe(resMor, 2)
                aoDigitar(buscaMor) { q ->
                    resMor.removeAllViews()
                    Moradores.buscar(q, moradores).forEach { m ->
                        val rot = if (m.unidade.isNotBlank()) "${m.nome} · ${m.unidade}" else m.nome
                        resMor.poe(botao(rot, Color.WHITE, TEXTO) {
                            e.nome = m.nome; e.unidade = m.unidade; e.telefone = m.telefone
                            e.semDestino = false
                            Banco.salvar(this, encomendas)
                            aviso("Morador definido: ${m.nome}")
                            telaDetalhe(e)
                        }.apply {
                            background = fundo(Color.WHITE, 12, BORDA)
                            gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        }, 6)
                    }
                }
            }
            if (e.telefone.isNotBlank() && e.atrasada()) {
                col.poe(botao("🔔 Enviar lembrete (${e.diasAguardando()} dias aguardando)", LARANJA) {
                    enviarLembrete(e)
                    telaDetalhe(e)
                }, 20)
            } else if (e.telefone.isNotBlank()) {
                col.poe(botao(if (e.avisadoEm > 0) "📲 Avisar de novo no WhatsApp" else "📲 Avisar no WhatsApp", VERDE) {
                    e.avisadoEm = System.currentTimeMillis()
                    Banco.salvar(this, encomendas)
                    telaDetalhe(e)
                    enviarWhats(e)
                }, 20)
            }
            col.poe(texto(if (e.semDestino) "Retirada ou devolução" else "Entrega ao morador", 18f, TEXTO, true), 24)
            val quem = campo("Quem retirou (nome)")
            col.poe(quem, 6)
            if (e.semDestino) {
                col.poe(botao("↩ Devolvido ao entregador", CINZA, TEXTO) {
                    quem.setText("Devolvido ao entregador")
                }.apply { textSize = 14f; minHeight = dp(42) }, 6)
            }

            // ---- Assinatura na tela
            val linhaAss = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            linhaAss.addView(texto("Assinatura de quem retirou", 16f, TEXTO, true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val quadro = Assinatura(this).apply {
                background = fundo(Color.WHITE, 12, BORDA)
                contentDescription = "Área para assinar com o dedo"
            }
            linhaAss.addView(botao("Limpar", CINZA, TEXTO) { quadro.limpar() }.apply {
                textSize = 14f; minHeight = dp(40)
            })
            col.poe(linhaAss, 16)
            col.poe(quadro.apply { minimumHeight = dp(200) }, 6)
            col.poe(texto("Assine com o dedo dentro do quadro.", 13f, SUAVE), 4)

            fun concluirEntrega(comAssinatura: Boolean) {
                if (comAssinatura) {
                    val pasta = File(filesDir, "assinaturas").apply { mkdirs() }
                    val arq = File(pasta, "assinatura_${e.id}.png")
                    if (quadro.salvar(arq)) e.assinatura = arq.absolutePath
                }
                e.retiradoPor = quem.text.toString().trim()
                e.entregueEm = System.currentTimeMillis()
                Banco.salvar(this, encomendas)
                aviso("Entrega registrada.")
                telaInicio()
            }

            col.poe(botao("✅ Confirmar entrega", AZUL) {
                if (quadro.vazia) {
                    AlertDialog.Builder(this)
                        .setTitle("Entregar sem assinatura?")
                        .setMessage("A pessoa ainda não assinou no quadro.")
                        .setPositiveButton("Entregar mesmo assim") { _, _ -> concluirEntrega(false) }
                        .setNegativeButton("Voltar e assinar", null)
                        .show()
                } else {
                    concluirEntrega(true)
                }
            }, 12)
        } else {
            col.poe(botao("Desfazer entrega", CINZA, TEXTO) {
                if (e.assinatura.isNotBlank()) File(e.assinatura).delete()
                e.assinatura = ""
                e.entregueEm = 0L
                e.retiradoPor = ""
                Banco.salvar(this, encomendas)
                telaDetalhe(e)
            }, 20)
        }

        col.poe(botao("Excluir registro", CINZA, VERMELHO) {
            AlertDialog.Builder(this)
                .setTitle("Excluir esta encomenda?")
                .setMessage("O registro e as fotos serão apagados.")
                .setPositiveButton("Excluir") { _, _ ->
                    if (e.fotoEtiqueta.isNotBlank()) File(e.fotoEtiqueta).delete()
                    if (e.fotoPacote.isNotBlank()) File(e.fotoPacote).delete()
                    if (e.assinatura.isNotBlank()) File(e.assinatura).delete()
                    encomendas.remove(e)
                    Banco.salvar(this, encomendas)
                    telaInicio()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }, 24)
    }

    // =======================================================================
    // Relatórios
    // =======================================================================
    private fun telaRelatorios() {
        tela = "relatorios"
        val hoje = Relatorio.inicioDoDia(System.currentTimeMillis())
        if (relInicio == 0L || relFim <= relInicio) { relInicio = hoje; relFim = Relatorio.somarDias(hoje, 1) }

        val col = novaPagina("📊 Relatórios", true)
        val opcoes = listOf(
            "Hoje" to (hoje to Relatorio.somarDias(hoje, 1)),
            "Ontem" to (Relatorio.somarDias(hoje, -1) to hoje),
            "Últimos 7 dias" to (Relatorio.somarDias(hoje, -6) to Relatorio.somarDias(hoje, 1)),
            "Este mês" to (Relatorio.inicioDoMes(hoje) to Relatorio.somarDias(hoje, 1))
        )
        val atual = opcoes.firstOrNull { it.second.first == relInicio && it.second.second == relFim }?.first ?: "Escolher datas"
        col.poe(linhaOpcoes("Período", opcoes.map { it.first } + "Escolher datas", atual) { escolha ->
            val p = opcoes.firstOrNull { it.first == escolha }
            if (p != null) {
                relInicio = p.second.first; relFim = p.second.second; telaRelatorios()
            } else if (escolha == "Escolher datas" || atual == "Escolher datas") {
                escolherDatas()
            } else {
                telaRelatorios()
            }
        }, 16)

        val itens = Relatorio.filtrar(encomendas, relInicio, relFim)
        val entregues = itens.count { it.entregue }
        col.poe(texto(Relatorio.periodo(relInicio, relFim), 17f, TEXTO, true), 16)

        val resumo = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        resumo.addView(caixaResumo("${itens.size}", "Chegaram", AZUL),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })
        resumo.addView(caixaResumo("$entregues", "Entregues", VERDE),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })
        resumo.addView(caixaResumo("${itens.size - entregues}", "Aguardando", LARANJA),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.poe(resumo, 10)

        col.poe(botao("📄 Compartilhar PDF", AZUL) {
            compartilhar(Relatorio.gerarPdf(this, itens, relInicio, relFim), "application/pdf")
        }, 16)
        col.poe(botao("📊 Compartilhar planilha (Excel)", VERDE) {
            compartilhar(Relatorio.gerarCsv(this, itens, relInicio, relFim), "text/csv")
        }, 8)

        col.poe(texto("Encomendas do período", 16f, TEXTO, true), 22)
        if (itens.isEmpty()) col.poe(texto("Nenhuma encomenda recebida neste período.", 15f, SUAVE), 8)
        itens.forEach { col.poe(cartao(it).apply { background = fundo(Color.parseColor("#F3F5F8"), 14) }, 8) }
    }

    private fun caixaResumo(numero: String, rotulo: String, cor: Int): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = fundo(Color.parseColor("#F3F5F8"), 14)
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        c.addView(texto(numero, 26f, cor, true).apply { gravity = Gravity.CENTER })
        c.addView(texto(rotulo, 13f, SUAVE).apply { gravity = Gravity.CENTER })
        return c
    }

    private fun escolherDatas() {
        val c = Calendar.getInstance().apply { timeInMillis = relInicio }
        DatePickerDialog(this, { _, a1, m1, d1 ->
            val ini = Calendar.getInstance().apply { set(a1, m1, d1, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            aviso("Agora escolha a data final")
            val c2 = Calendar.getInstance().apply { timeInMillis = maxOf(ini, relFim - 1) }
            DatePickerDialog(this, { _, a2, m2, d2 ->
                val fimDia = Calendar.getInstance().apply { set(a2, m2, d2, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                relInicio = minOf(ini, fimDia)
                relFim = Relatorio.somarDias(maxOf(ini, fimDia), 1)
                telaRelatorios()
            }, c2.get(Calendar.YEAR), c2.get(Calendar.MONTH), c2.get(Calendar.DAY_OF_MONTH)).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun compartilhar(arquivo: File, tipo: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fotos", arquivo)
            val envio = Intent(Intent.ACTION_SEND).apply {
                type = tipo
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Relatório de encomendas – " + Relatorio.periodo(relInicio, relFim))
                clipData = ClipData.newRawUri("relatorio", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(envio, "Compartilhar relatório"))
        } catch (e: Exception) {
            aviso("Não consegui compartilhar: ${e.message}")
        }
    }

    // =======================================================================
    // Ativação (teste de 5 dias)
    // =======================================================================
    private fun telaAtivar() {
        tela = "ativar"
        val bloqueado = Licenca.bloqueado(this)
        val col = novaPagina("Ativar o app", !bloqueado)
        val codigo = Licenca.codigoAparelho(this)

        val mensagem = if (bloqueado) "O período de teste de ${Licenca.DIAS_TESTE} dias terminou. Para continuar usando, ative o app."
        else "Você está na versão de teste. Faltam ${Licenca.diasRestantes(this)} dia(s)."
        col.poe(texto(mensagem, 16f, if (bloqueado) VERMELHO else TEXTO, bloqueado), 16)

        col.poe(texto("1. Envie este código do aparelho para a BM Soluções:", 15f, TEXTO, true), 20)
        col.poe(texto(codigo, 32f, AZUL, true).apply {
            gravity = Gravity.CENTER
            background = fundo(AZUL_CLARO, 14)
            setPadding(dp(12), dp(16), dp(12), dp(16))
            letterSpacing = 0.1f
        }, 8)
        col.poe(botao("📲 Enviar código pelo WhatsApp", VERDE) {
            val envio = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Olá! Quero ativar o BM Soluções App. Código do aparelho: $codigo")
            }
            try { startActivity(Intent.createChooser(envio, "Enviar código")) } catch (e: Exception) { aviso("Não consegui abrir o compartilhamento.") }
        }, 8)

        col.poe(texto("2. Digite o código de liberação que você recebeu:", 15f, TEXTO, true), 24)
        val campoLib = campo("XXXX-XXXX", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS).apply {
            textSize = 22f
            gravity = Gravity.CENTER
        }
        col.poe(campoLib, 8)
        col.poe(botao("🔓 Liberar", AZUL) {
            if (Licenca.tentarLiberar(this, campoLib.text.toString())) {
                AlertDialog.Builder(this)
                    .setTitle("App liberado! ✅")
                    .setMessage("Obrigado. O BM Soluções App está liberado definitivamente neste celular.")
                    .setPositiveButton("OK") { _, _ -> telaInicio() }
                    .setCancelable(false)
                    .show()
            } else {
                aviso("Código de liberação inválido. Confira e tente de novo.")
            }
        }, 10)
    }

    // =======================================================================
    // WhatsApp (abre a conversa com a mensagem pronta; o porteiro só aperta enviar)
    // =======================================================================
    private fun enviarLembrete(e: Encomenda) {
        e.lembreteEm = System.currentTimeMillis()
        Banco.salvar(this, encomendas)
        enviarWhats(e, true)
    }

    private fun enviarWhats(e: Encomenda, lembrete: Boolean = false) {
        val fone = Texto.telefoneWhats(e.telefone)
        if (fone.length < 12) { aviso("Telefone inválido: ${e.telefone}"); return }
        val primeiroNome = e.nome.trim().split(" ").firstOrNull().orEmpty()
        val desc = e.descricao()
        val dataChegada = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(e.recebidoEm))
        val msg = buildString {
            append("Olá, $primeiroNome! 📦\n\n")
            if (lembrete) {
                append("*Lembrete:* sua encomenda")
                if (desc.isNotBlank()) append(" (*${desc.lowercase()}*)")
                append(" está aguardando retirada desde $dataChegada (${e.diasAguardando()} dias).")
            } else {
                append("Chegou uma encomenda")
                if (e.emNomeDe.isNotBlank()) append(" em nome de *${e.emNomeDe}*")
                else append(" para você")
                if (desc.isNotBlank()) append(": *${desc.lowercase()}*.") else append(".")
            }
            if (e.rastreio.isNotBlank()) append("\nCódigo: ${e.rastreio}")
            append("\n\n").append(fraseFinal())
        }
        val ordem = if (whatsEscolhido() == "Normal") listOf("com.whatsapp", "com.whatsapp.w4b", null)
        else listOf("com.whatsapp.w4b", "com.whatsapp", null)

        // Com foto do pacote: abre a conversa do morador com a foto e o texto como legenda.
        val foto = File(e.fotoPacote)
        if (enviarFotoNaMensagem() && e.fotoPacote.isNotBlank() && foto.exists()) {
            try {
                val uriFoto = FileProvider.getUriForFile(this, "$packageName.fotos", foto)
                for (pacote in ordem.filterNotNull()) {
                    try {
                        val envio = Intent(Intent.ACTION_SEND).apply {
                            type = "image/jpeg"
                            putExtra(Intent.EXTRA_STREAM, uriFoto)
                            putExtra(Intent.EXTRA_TEXT, msg)
                            putExtra("jid", "$fone@s.whatsapp.net")
                            setPackage(pacote)
                            clipData = ClipData.newRawUri("foto", uriFoto)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(envio)
                        return
                    } catch (ex: ActivityNotFoundException) {
                        // tenta o próximo
                    }
                }
            } catch (ex: Exception) {
                // se der errado com a foto, envia só o texto
            }
        }

        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$fone&text=" + Uri.encode(msg))
        for (pacote in ordem) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri)
                if (pacote != null) intent.setPackage(pacote)
                startActivity(intent)
                return
            } catch (ex: ActivityNotFoundException) {
                // tenta o próximo
            }
        }
        aviso("WhatsApp não encontrado neste celular.")
    }

    // =======================================================================
    // Configuração da mensagem (cada condomínio pode ter um texto)
    // =======================================================================
    private fun fraseFinal(): String =
        getSharedPreferences("config", MODE_PRIVATE).getString("fraseFinal", null)
            ?.takeIf { it.isNotBlank() } ?: FRASE_PADRAO

    private fun telaConfig() {
        tela = "config"
        val col = novaPagina("⚙ Mensagem", true)
        col.poe(texto("Frase do final da mensagem do WhatsApp:", 16f, TEXTO, true), 16)
        val campoFrase = campo("Ex.: Já está disponível na portaria.", fraseFinal(),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
            .apply { maxLines = 4 }
        col.poe(campoFrase, 6)
        col.poe(texto("Exemplo de como o morador vai receber:", 14f, SUAVE), 16)
        val exemplo = texto("", 15f).apply {
            background = fundo(VERDE_CLARO, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        fun atualizarExemplo(f: String) {
            exemplo.text = "Olá, Antônio! 📦\n\nChegou uma encomenda para você: *caixa pequena preta*.\nCódigo: LP123456789CN\n\n" +
                f.ifBlank { FRASE_PADRAO }
        }
        atualizarExemplo(campoFrase.text.toString())
        aoDigitar(campoFrase) { atualizarExemplo(it) }
        col.poe(exemplo, 6)
        col.poe(botao("💾 Salvar", VERDE) {
            getSharedPreferences("config", MODE_PRIVATE).edit()
                .putString("fraseFinal", campoFrase.text.toString().trim()).apply()
            aviso("Mensagem salva.")
            telaInicio()
        }, 20)
        col.poe(botao("Voltar ao padrão", CINZA, TEXTO) {
            campoFrase.setText(FRASE_PADRAO)
        }, 8)

        col.poe(linhaOpcoes("WhatsApp usado para enviar", listOf("Business", "Normal"), whatsEscolhido()) { escolha ->
            if (escolha.isNotBlank()) {
                getSharedPreferences("config", MODE_PRIVATE).edit().putString("whatsapp", escolha).apply()
                aviso("As mensagens vão abrir no WhatsApp $escolha.")
            }
        }, 28)
        col.poe(texto("Se o WhatsApp escolhido não estiver instalado, o app usa o outro.", 13f, SUAVE), 4)

        col.poe(linhaOpcoes("Enviar a foto do pacote junto", listOf("Sim", "Não"), if (enviarFotoNaMensagem()) "Sim" else "Não") { escolha ->
            if (escolha.isNotBlank()) {
                getSharedPreferences("config", MODE_PRIVATE).edit().putBoolean("enviarFoto", escolha == "Sim").apply()
            }
        }, 24)
        col.poe(texto("Quando tiver foto do pacote, ela vai na mensagem com o texto como legenda.", 13f, SUAVE), 4)

        // ---- Encaminhamentos salvos
        val encs = Encaminhamentos.carregar(this)
        col.poe(texto("Encaminhamentos salvos", 16f, TEXTO, true), 28)
        col.poe(texto("Encomendas no nome da esquerda são avisadas para o contato da direita.", 13f, SUAVE), 4)
        if (encs.isEmpty()) col.poe(texto("Nenhum ainda. Eles são criados na tela de nova encomenda, no campo \"Veio no nome de outra pessoa?\".", 14f, SUAVE), 8)
        encs.forEach { enc ->
            val linha = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = fundo(Color.parseColor("#F3F5F8"), 12)
                setPadding(dp(12), dp(8), dp(8), dp(8))
            }
            linha.addView(texto("${enc.nomeEtiqueta}  →  ${enc.nome}" + (if (enc.unidade.isNotBlank()) " · ${enc.unidade}" else ""), 15f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            linha.addView(botao("Apagar", CINZA, VERMELHO) {
                val lista = Encaminhamentos.carregar(this)
                lista.removeAll { it.nomeEtiqueta == enc.nomeEtiqueta }
                Encaminhamentos.salvar(this, lista)
                aviso("Encaminhamento apagado.")
                telaConfig()
            }.apply { textSize = 14f; minHeight = dp(40) })
            col.poe(linha, 8)
        }
    }

    private fun enviarFotoNaMensagem(): Boolean =
        getSharedPreferences("config", MODE_PRIVATE).getBoolean("enviarFoto", true)

    /** "Business" (padrão) ou "Normal". */
    private fun whatsEscolhido(): String =
        getSharedPreferences("config", MODE_PRIVATE).getString("whatsapp", null) ?: "Business"

    // =======================================================================
    // Componentes visuais
    // =======================================================================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fundo(cor: Int, raio: Int = 12, borda: Int? = null) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
        if (borda != null) setStroke(dp(1), borda)
    }

    private fun novaPagina(titulo: String, voltar: Boolean): LinearLayout {
        campoRastreio = null
        campoObs = null
        campoEmNome = null
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.WHITE)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        scroll.addView(col)
        val cab = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (voltar) {
            val b = Button(this).apply {
                text = "←"
                textSize = 20f
                setTextColor(TEXTO)
                background = fundo(CINZA, 24)
                contentDescription = "Voltar"
                setOnClickListener { onBackPressed() }
            }
            cab.addView(b, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) })
        }
        cab.addView(texto(titulo, 22f, TEXTO, true))
        col.addView(cab)
        setContentView(scroll)
        return col
    }

    private fun LinearLayout.poe(v: View, topo: Int = 10) {
        addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topo) })
    }

    private fun texto(t: String, tamanho: Float = 16f, cor: Int = TEXTO, negrito: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = tamanho
            setTextColor(cor)
            if (negrito) setTypeface(null, Typeface.BOLD)
        }

    private fun botao(t: String, cor: Int = AZUL, corTexto: Int = Color.WHITE, acao: () -> Unit) =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 17f
            setTextColor(corTexto)
            background = fundo(cor, 12)
            minHeight = dp(52)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { acao() }
        }

    private fun campo(dica: String, valor: String = "",
                      tipo: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS) =
        EditText(this).apply {
            hint = dica
            setText(valor)
            inputType = tipo
            maxLines = 1
            textSize = 17f
            setTextColor(TEXTO)
            background = fundo(Color.WHITE, 10, BORDA)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

    private fun aoDigitar(e: EditText, acao: (String) -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { acao(s?.toString() ?: "") }
        })
    }

    /** Linha de botões de escolha única (toque de novo para desmarcar). */
    private fun linhaOpcoes(rotulo: String, opcoes: List<String>, atual: String, aoEscolher: (String) -> Unit): View {
        val caixa = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        caixa.addView(texto(rotulo, 16f, TEXTO, true))
        val rolagem = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val botoes = mutableListOf<Button>()
        var selecionado = atual

        fun pintar() {
            botoes.forEach { b ->
                val ativo = b.text.toString() == selecionado
                b.background = fundo(if (ativo) AZUL else CINZA, 20)
                b.setTextColor(if (ativo) Color.WHITE else TEXTO)
            }
        }

        opcoes.forEach { op ->
            val b = Button(this).apply {
                text = op
                isAllCaps = false
                textSize = 15f
                minHeight = dp(44)
                minimumHeight = dp(44)
                setPadding(dp(16), dp(4), dp(16), dp(4))
                setOnClickListener {
                    selecionado = if (selecionado == op) "" else op
                    aoEscolher(selecionado)
                    pintar()
                }
            }
            botoes.add(b)
            linha.addView(b, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(8) })
        }
        pintar()
        rolagem.addView(linha)
        caixa.addView(rolagem, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })
        return caixa
    }

    private fun imagem(caminho: String, alturaMax: Int): View? {
        val bmp = carregarFoto(caminho, 900) ?: return null
        return ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            maxHeight = dp(alturaMax)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = fundo(CINZA, 10)
        }
    }

    /** Abre a foto já reduzida e na posição certa (corrige a rotação da câmera). */
    private fun carregarFoto(caminho: String, ladoMax: Int): Bitmap? {
        val f = File(caminho)
        if (!f.exists()) return null
        val limites = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(caminho, limites)
        if (limites.outWidth <= 0 || limites.outHeight <= 0) return null
        var escala = 1
        while (limites.outWidth / (escala * 2) >= ladoMax && limites.outHeight / (escala * 2) >= ladoMax) escala *= 2
        val bmp = BitmapFactory.decodeFile(caminho, BitmapFactory.Options().apply { inSampleSize = escala }) ?: return null
        val graus = try {
            when (ExifInterface(caminho).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) { 0f }
        if (graus == 0f) return bmp
        val m = Matrix().apply { postRotate(graus) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    /** Reduz a foto salva (lado maior até [ladoMaior] px, JPEG 82%) para economizar espaço. */
    private fun comprimirFoto(caminho: String, ladoMaior: Int) {
        try {
            val original = carregarFoto(caminho, ladoMaior / 2) ?: return
            val maior = maxOf(original.width, original.height)
            val bmp = if (maior > ladoMaior) {
                val fator = ladoMaior.toFloat() / maior
                Bitmap.createScaledBitmap(original, (original.width * fator).toInt(), (original.height * fator).toInt(), true)
            } else original
            val tmp = File("$caminho.tmp")
            FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            if (!tmp.renameTo(File(caminho))) {
                File(caminho).delete()
                tmp.renameTo(File(caminho))
            }
        } catch (e: Exception) {
            // se falhar, mantém a foto original
        }
    }

    private fun aviso(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
