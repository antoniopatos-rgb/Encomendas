package br.com.bmsolucoes.encomendas

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        private const val REQ_ETIQUETA = 10
        private const val REQ_PACOTE = 11
        private const val REQ_CONTATOS = 20

        private val AZUL = Color.parseColor("#1565C0")
        private val VERDE = Color.parseColor("#2E7D32")
        private val VERDE_CLARO = Color.parseColor("#E8F5E9")
        private val VERMELHO = Color.parseColor("#C62828")
        private val CINZA = Color.parseColor("#ECEFF1")
        private val BORDA = Color.parseColor("#B0BEC5")
        private val TEXTO = Color.parseColor("#212121")
        private val SUAVE = Color.parseColor("#616161")

        private val TIPOS = listOf("Caixa", "Envelope", "Saco plástico", "Sacola", "Outro")
        private val TAMANHOS = listOf("Pequeno", "Médio", "Grande")
        private val CORES = listOf("Preto", "Branco", "Pardo", "Cinza", "Azul", "Amarelo", "Colorido")
        private val LOCAIS = listOf("Prateleira 1", "Prateleira 2", "Prateleira 3", "Chão", "Armário")
    }

    private var tela = "inicio"
    private var encomendas = mutableListOf<Encomenda>()
    private var moradores = listOf<Morador>()
    private var rascunho: Encomenda? = null
    private var textoEtiqueta = ""
    private var fotoPendente: String? = null
    private var detalheId = 0L
    private var mostrarEntregues = false
    private val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

    private var campoRastreio: EditText? = null
    private var campoObs: EditText? = null

    // =======================================================================
    // Ciclo de vida
    // =======================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        encomendas = Banco.carregar(this)
        if (savedInstanceState != null) {
            tela = savedInstanceState.getString("tela") ?: "inicio"
            fotoPendente = savedInstanceState.getString("fotoPendente")
            textoEtiqueta = savedInstanceState.getString("textoEtiqueta") ?: ""
            detalheId = savedInstanceState.getLong("detalheId")
            mostrarEntregues = savedInstanceState.getBoolean("mostrarEntregues")
            savedInstanceState.getString("rascunho")?.let {
                rascunho = try { Encomenda.fromJson(JSONObject(it)) } catch (e: Exception) { null }
            }
        }
        carregarMoradores()
        if (!temPermissaoContatos()) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTATOS)
        }
        mostrarTelaAtual()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        lerCampos()
        outState.putString("tela", tela)
        outState.putString("fotoPendente", fotoPendente)
        outState.putString("textoEtiqueta", textoEtiqueta)
        outState.putLong("detalheId", detalheId)
        outState.putBoolean("mostrarEntregues", mostrarEntregues)
        rascunho?.let { outState.putString("rascunho", it.toJson().toString()) }
        super.onSaveInstanceState(outState)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CONTATOS) {
            carregarMoradores()
            if (tela == "inicio") telaInicio()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (tela) {
            "nova" -> descartar()
            "detalhe" -> telaInicio()
            else -> super.onBackPressed()
        }
    }

    private fun mostrarTelaAtual() {
        when (tela) {
            "nova" -> if (rascunho != null) telaNova() else telaInicio()
            "detalhe" -> encomendas.find { it.id == detalheId }?.let { telaDetalhe(it) } ?: telaInicio()
            else -> telaInicio()
        }
    }

    private fun temPermissaoContatos() =
        checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun carregarMoradores() {
        moradores = if (temPermissaoContatos()) {
            try { Moradores.carregar(this) } catch (e: Exception) { emptyList() }
        } else emptyList()
    }

    // =======================================================================
    // Tela inicial: lista de encomendas
    // =======================================================================
    private fun telaInicio() {
        tela = "inicio"
        val col = novaPagina("📦 Encomendas", false)
        col.poe(texto("BM Soluções · Portaria", 13f, SUAVE), 2)

        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val info = if (!temPermissaoContatos()) "⚠ Sem permissão para ler os contatos"
        else "${moradores.size} contatos carregados"
        linha.addView(texto(info, 14f, SUAVE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        linha.addView(botao("Atualizar", CINZA, TEXTO) {
            if (!temPermissaoContatos()) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTATOS)
            } else {
                carregarMoradores(); telaInicio(); aviso("${moradores.size} contatos carregados")
            }
        }.apply { textSize = 14f; minHeight = dp(40) })
        col.poe(linha, 8)

        col.poe(botao("📷  NOVA ENCOMENDA", VERDE) { abrirCamera(REQ_ETIQUETA) }.apply {
            textSize = 20f; minHeight = dp(72)
        }, 16)

        val pendentes = encomendas.count { !it.entregue }
        val abas = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        abas.addView(aba("Na portaria ($pendentes)", !mostrarEntregues) { mostrarEntregues = false; telaInicio() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        abas.addView(aba("Entregues", mostrarEntregues) { mostrarEntregues = true; telaInicio() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.poe(abas, 20)

        val busca = campo("🔍 Buscar por nome, casa ou código")
        col.poe(busca, 10)
        val lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.poe(lista, 4)

        fun mostrarLista(consulta: String) {
            lista.removeAllViews()
            val q = Texto.normalizar(consulta)
            val itens = encomendas
                .filter { it.entregue == mostrarEntregues }
                .filter { q.isEmpty() || Texto.normalizar("${it.nome} ${it.unidade} ${it.rastreio} ${it.descricao()}").contains(q) }
                .sortedByDescending { if (mostrarEntregues) it.entregueEm else it.recebidoEm }
                .take(200)
            if (itens.isEmpty()) {
                lista.poe(texto("Nenhuma encomenda aqui.", 15f, SUAVE), 12)
            }
            itens.forEach { lista.poe(cartao(it), 8) }
        }
        aoDigitar(busca) { mostrarLista(it) }
        mostrarLista("")
    }

    private fun cartao(e: Encomenda): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = fundo(CINZA, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { telaDetalhe(e) }
        }
        val titulo = if (e.unidade.isNotBlank()) "${e.nome} · ${e.unidade}" else e.nome
        c.addView(texto(titulo, 17f, TEXTO, true))
        val desc = listOf(e.descricao(), e.local).filter { it.isNotBlank() }.joinToString(" · ")
        if (desc.isNotBlank()) c.addView(texto(desc, 15f))
        val status = if (e.entregue) {
            "✅ Entregue " + formato.format(Date(e.entregueEm)) +
                (if (e.retiradoPor.isNotBlank()) " para ${e.retiradoPor}" else "")
        } else {
            "Recebida " + formato.format(Date(e.recebidoEm)) +
                (if (e.avisadoEm > 0) " · 📲 avisado" else " · ⚠ não avisado")
        }
        c.addView(texto(status, 13f, SUAVE))
        return c
    }

    // =======================================================================
    // Câmera
    // =======================================================================
    private fun abrirCamera(req: Int) {
        val pasta = File(filesDir, "fotos").apply { mkdirs() }
        val prefixo = if (req == REQ_ETIQUETA) "etiqueta_" else "pacote_"
        val arq = File(pasta, prefixo + System.currentTimeMillis() + ".jpg")
        fotoPendente = arq.absolutePath
        val uri = FileProvider.getUriForFile(this, "$packageName.fotos", arq)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            clipData = ClipData.newRawUri("foto", uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, req)
        } catch (e: ActivityNotFoundException) {
            fotoPendente = null
            aviso("Não encontrei o app de câmera.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_ETIQUETA && requestCode != REQ_PACOTE) return
        val caminho = fotoPendente
        fotoPendente = null
        val ok = resultCode == RESULT_OK && caminho != null && File(caminho).length() > 0
        if (!ok || caminho == null) {
            caminho?.let { File(it).delete() }
            if (requestCode == REQ_ETIQUETA) telaInicio() else if (rascunho != null) telaNova() else telaInicio()
            return
        }
        if (requestCode == REQ_ETIQUETA) {
            rascunho = Encomenda(fotoEtiqueta = caminho, recebidoEm = System.currentTimeMillis())
            textoEtiqueta = ""
            processarEtiqueta(caminho)
        } else {
            val r = rascunho
            if (r == null) { File(caminho).delete(); telaInicio(); return }
            if (r.fotoPacote.isNotBlank()) File(r.fotoPacote).delete()
            r.fotoPacote = caminho
            telaNova()
        }
    }

    // =======================================================================
    // Leitura da etiqueta (texto + código de barras), tudo no celular
    // =======================================================================
    private fun processarEtiqueta(caminho: String) {
        tela = "nova"
        val col = novaPagina("Lendo etiqueta…", false)
        imagem(caminho, 260)?.let { col.poe(it, 12) }
        col.poe(ProgressBar(this), 20)
        col.poe(texto("Aguarde, lendo o nome e o código…", 15f, SUAVE).apply { gravity = Gravity.CENTER }, 8)

        val bmp = carregarFoto(caminho, 1000)
        if (bmp == null) {
            aviso("Não consegui abrir a foto.")
            telaNova()
            return
        }
        val img = InputImage.fromBitmap(bmp, 0)
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
            .addOnCompleteListener { t ->
                if (t.isSuccessful) textoEtiqueta = t.result?.text ?: ""
                BarcodeScanning.getClient().process(img)
                    .addOnCompleteListener { b ->
                        val codigos = if (b.isSuccessful) b.result?.mapNotNull { it.rawValue } ?: emptyList() else emptyList()
                        rascunho?.rastreio = Rastreio.escolher(codigos, textoEtiqueta)
                        if (!isFinishing && tela == "nova") telaNova()
                    }
            }
    }

    // =======================================================================
    // Tela de nova encomenda
    // =======================================================================
    private fun telaNova() {
        val r = rascunho ?: return telaInicio()
        tela = "nova"
        val col = novaPagina("Nova encomenda", true)
        imagem(r.fotoEtiqueta, 180)?.let { col.poe(it, 12) }

        // ---- Morador
        col.poe(texto("Morador", 18f, TEXTO, true), 16)
        if (r.nome.isNotBlank()) {
            val caixa = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(VERDE_CLARO, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            caixa.addView(texto("✔ ${r.nome}", 18f, VERDE, true))
            if (r.unidade.isNotBlank()) caixa.addView(texto(r.unidade, 16f))
            caixa.addView(texto(if (r.telefone.isNotBlank()) "WhatsApp: ${r.telefone}" else "⚠ Contato sem telefone", 14f, SUAVE))
            col.poe(caixa, 6)
            col.poe(botao("Trocar morador", CINZA, TEXTO) {
                lerCampos(); r.nome = ""; r.unidade = ""; r.telefone = ""; telaNova()
            }, 6)
        } else {
            val sugestoes = Moradores.sugerir(textoEtiqueta, moradores)
            if (sugestoes.isNotEmpty()) {
                col.poe(texto("Sugestões pela etiqueta (toque no certo):", 14f, SUAVE), 4)
                sugestoes.forEach { col.poe(botaoMorador(it.morador), 6) }
            } else {
                val msg = if (moradores.isEmpty())
                    "⚠ Nenhum contato carregado. Cadastre os moradores nos contatos do celular."
                else "Não reconheci o nome na etiqueta. Busque abaixo:"
                col.poe(texto(msg, 14f, SUAVE), 4)
            }
            val busca = campo("Buscar por nome ou nº da casa")
            col.poe(busca, 10)
            val resultados = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.poe(resultados, 2)
            aoDigitar(busca) { q ->
                resultados.removeAllViews()
                Moradores.buscar(q, moradores).forEach { resultados.poe(botaoMorador(it), 6) }
            }
        }

        // ---- Código de rastreio
        col.poe(texto("Código de rastreio", 16f, TEXTO, true), 20)
        campoRastreio = campo("Ex.: LP123456789CN", r.rastreio,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS).also { col.poe(it, 6) }

        // ---- Descrição do pacote
        col.poe(linhaOpcoes("Tipo", TIPOS, r.tipo) { r.tipo = it }, 16)
        col.poe(linhaOpcoes("Tamanho", TAMANHOS, r.tamanho) { r.tamanho = it }, 12)
        col.poe(linhaOpcoes("Cor", CORES, r.cor) { r.cor = it }, 12)
        col.poe(linhaOpcoes("Onde guardou", LOCAIS, r.local) { r.local = it }, 12)

        col.poe(texto("Observação", 16f, TEXTO, true), 16)
        campoObs = campo("Ex.: frágil, 2 volumes", r.obs,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES).also { col.poe(it, 6) }

        // ---- Foto do pacote
        col.poe(texto("Foto do pacote (opcional)", 16f, TEXTO, true), 16)
        if (r.fotoPacote.isNotBlank()) imagem(r.fotoPacote, 180)?.let { col.poe(it, 6) }
        col.poe(botao(if (r.fotoPacote.isBlank()) "📷 Tirar foto do pacote" else "📷 Refazer foto do pacote", CINZA, TEXTO) {
            lerCampos(); abrirCamera(REQ_PACOTE)
        }, 6)

        // ---- Ações
        col.poe(botao("✅ Salvar e avisar no WhatsApp", VERDE) { salvar(true) }, 24)
        col.poe(botao("Salvar sem avisar", AZUL) { salvar(false) }, 8)
        col.poe(botao("Cancelar", CINZA, VERMELHO) { descartar() }, 8)
    }

    private fun botaoMorador(m: Morador): Button {
        val rotulo = if (m.unidade.isNotBlank()) "${m.nome} · ${m.unidade}" else m.nome
        return botao(rotulo, Color.WHITE, TEXTO) {
            lerCampos()
            rascunho?.let { r -> r.nome = m.nome; r.unidade = m.unidade; r.telefone = m.telefone }
            telaNova()
        }.apply {
            background = fundo(Color.WHITE, 12, BORDA)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }
    }

    private fun lerCampos() {
        if (tela != "nova") return
        val r = rascunho ?: return
        campoRastreio?.let { r.rastreio = it.text.toString().trim().uppercase() }
        campoObs?.let { r.obs = it.text.toString().trim() }
    }

    private fun salvar(avisar: Boolean) {
        lerCampos()
        val r = rascunho ?: return
        if (r.nome.isBlank()) { aviso("Escolha o morador primeiro."); return }
        if (avisar && r.telefone.isBlank()) { aviso("Esse contato não tem telefone."); return }
        val agora = System.currentTimeMillis()
        val e = r.copy(id = agora)
        if (avisar) e.avisadoEm = agora
        encomendas.add(e)
        Banco.salvar(this, encomendas)
        rascunho = null
        textoEtiqueta = ""
        mostrarEntregues = false
        telaInicio()
        aviso("Encomenda registrada.")
        if (avisar) enviarWhats(e)
    }

    private fun descartar() {
        AlertDialog.Builder(this)
            .setTitle("Descartar esta encomenda?")
            .setMessage("As fotos e os dados preenchidos serão apagados.")
            .setPositiveButton("Descartar") { _, _ ->
                rascunho?.let { r ->
                    if (r.fotoEtiqueta.isNotBlank()) File(r.fotoEtiqueta).delete()
                    if (r.fotoPacote.isNotBlank()) File(r.fotoPacote).delete()
                }
                rascunho = null
                textoEtiqueta = ""
                telaInicio()
            }
            .setNegativeButton("Continuar", null)
            .show()
    }

    // =======================================================================
    // Detalhe / entrega
    // =======================================================================
    private fun telaDetalhe(e: Encomenda) {
        tela = "detalhe"
        detalheId = e.id
        val col = novaPagina("Encomenda", true)
        col.poe(texto(e.nome, 22f, TEXTO, true), 12)
        if (e.unidade.isNotBlank()) col.poe(texto(e.unidade, 17f), 2)

        val infos = listOf(
            "Pacote" to e.descricao(),
            "Onde está" to e.local,
            "Código" to e.rastreio,
            "Obs." to e.obs,
            "Recebida" to formato.format(Date(e.recebidoEm)),
            "Aviso no WhatsApp" to (if (e.avisadoEm > 0) formato.format(Date(e.avisadoEm)) else "não enviado")
        )
        infos.filter { it.second.isNotBlank() }.forEach { (k, v) -> col.poe(texto("$k: $v", 16f), 6) }

        if (e.entregue) {
            val caixa = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = fundo(VERDE_CLARO, 12)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            caixa.addView(texto("✅ Entregue em ${formato.format(Date(e.entregueEm))}", 16f, VERDE, true))
            if (e.retiradoPor.isNotBlank()) caixa.addView(texto("Retirado por: ${e.retiradoPor}", 15f))
            col.poe(caixa, 14)
        }

        if (e.fotoPacote.isNotBlank()) {
            col.poe(texto("Foto do pacote", 15f, SUAVE), 16)
            imagem(e.fotoPacote, 260)?.let { col.poe(it, 4) }
        }
        if (e.fotoEtiqueta.isNotBlank()) {
            col.poe(texto("Foto da etiqueta", 15f, SUAVE), 16)
            imagem(e.fotoEtiqueta, 260)?.let { col.poe(it, 4) }
        }

        if (!e.entregue) {
            if (e.telefone.isNotBlank()) {
                col.poe(botao(if (e.avisadoEm > 0) "📲 Avisar de novo no WhatsApp" else "📲 Avisar no WhatsApp", VERDE) {
                    e.avisadoEm = System.currentTimeMillis()
                    Banco.salvar(this, encomendas)
                    telaDetalhe(e)
                    enviarWhats(e)
                }, 20)
            }
            col.poe(texto("Entrega ao morador", 18f, TEXTO, true), 24)
            val quem = campo("Quem retirou (nome)")
            col.poe(quem, 6)
            col.poe(botao("✅ Confirmar entrega", AZUL) {
                e.retiradoPor = quem.text.toString().trim()
                e.entregueEm = System.currentTimeMillis()
                Banco.salvar(this, encomendas)
                aviso("Entrega registrada.")
                telaInicio()
            }, 8)
        } else {
            col.poe(botao("Desfazer entrega", CINZA, TEXTO) {
                e.entregueEm = 0L
                e.retiradoPor = ""
                Banco.salvar(this, encomendas)
                telaDetalhe(e)
            }, 20)
        }

        col.poe(botao("Excluir registro", CINZA, VERMELHO) {
            AlertDialog.Builder(this)
                .setTitle("Excluir esta encomenda?")
                .setMessage("O registro e as fotos serão apagados.")
                .setPositiveButton("Excluir") { _, _ ->
                    if (e.fotoEtiqueta.isNotBlank()) File(e.fotoEtiqueta).delete()
                    if (e.fotoPacote.isNotBlank()) File(e.fotoPacote).delete()
                    encomendas.remove(e)
                    Banco.salvar(this, encomendas)
                    telaInicio()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }, 24)
    }

    // =======================================================================
    // WhatsApp (abre a conversa com a mensagem pronta; o porteiro só aperta enviar)
    // =======================================================================
    private fun enviarWhats(e: Encomenda) {
        val fone = Texto.telefoneWhats(e.telefone)
        if (fone.length < 12) { aviso("Telefone inválido: ${e.telefone}"); return }
        val primeiroNome = e.nome.trim().split(" ").firstOrNull().orEmpty()
        val desc = e.descricao()
        val msg = buildString {
            append("Olá, $primeiroNome! 📦\n\n")
            if (desc.isNotBlank()) append("Chegou uma encomenda para você: *${desc.lowercase()}*.")
            else append("Chegou uma encomenda para você.")
            if (e.rastreio.isNotBlank()) append("\nCódigo: ${e.rastreio}")
            append("\n\nJá está disponível na portaria para retirada.")
        }
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$fone&text=" + Uri.encode(msg))
        for (pacote in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri)
                if (pacote != null) intent.setPackage(pacote)
                startActivity(intent)
                return
            } catch (ex: ActivityNotFoundException) {
                // tenta o próximo
            }
        }
        aviso("WhatsApp não encontrado neste celular.")
    }

    // =======================================================================
    // Componentes visuais
    // =======================================================================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fundo(cor: Int, raio: Int = 12, borda: Int? = null) = GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raio).toFloat()
        if (borda != null) setStroke(dp(1), borda)
    }

    private fun novaPagina(titulo: String, voltar: Boolean): LinearLayout {
        campoRastreio = null
        campoObs = null
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.WHITE)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        scroll.addView(col)
        val cab = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (voltar) {
            val b = Button(this).apply {
                text = "←"
                textSize = 20f
                setTextColor(TEXTO)
                background = fundo(CINZA, 24)
                setOnClickListener { onBackPressed() }
            }
            cab.addView(b, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) })
        }
        cab.addView(texto(titulo, 22f, TEXTO, true))
        col.addView(cab)
        setContentView(scroll)
        return col
    }

    private fun LinearLayout.poe(v: View, topo: Int = 10) {
        addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topo) })
    }

    private fun texto(t: String, tamanho: Float = 16f, cor: Int = TEXTO, negrito: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = tamanho
            setTextColor(cor)
            if (negrito) setTypeface(null, Typeface.BOLD)
        }

    private fun botao(t: String, cor: Int = AZUL, corTexto: Int = Color.WHITE, acao: () -> Unit) =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 17f
            setTextColor(corTexto)
            background = fundo(cor, 12)
            minHeight = dp(52)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { acao() }
        }

    private fun aba(t: String, ativa: Boolean, acao: () -> Unit) =
        botao(t, if (ativa) AZUL else CINZA, if (ativa) Color.WHITE else TEXTO, acao).apply { textSize = 15f }

    private fun campo(dica: String, valor: String = "",
                      tipo: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS) =
        EditText(this).apply {
            hint = dica
            setText(valor)
            inputType = tipo
            maxLines = 1
            textSize = 17f
            setTextColor(TEXTO)
            background = fundo(Color.WHITE, 10, BORDA)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

    private fun aoDigitar(e: EditText, acao: (String) -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { acao(s?.toString() ?: "") }
        })
    }

    /** Linha de botões de escolha única (toque de novo para desmarcar). */
    private fun linhaOpcoes(rotulo: String, opcoes: List<String>, atual: String, aoEscolher: (String) -> Unit): View {
        val caixa = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        caixa.addView(texto(rotulo, 16f, TEXTO, true))
        val rolagem = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val botoes = mutableListOf<Button>()
        var selecionado = atual

        fun pintar() {
            botoes.forEach { b ->
                val ativo = b.text.toString() == selecionado
                b.background = fundo(if (ativo) AZUL else CINZA, 20)
                b.setTextColor(if (ativo) Color.WHITE else TEXTO)
            }
        }

        opcoes.forEach { op ->
            val b = Button(this).apply {
                text = op
                isAllCaps = false
                textSize = 15f
                minHeight = dp(44)
                minimumHeight = dp(44)
                setPadding(dp(16), dp(4), dp(16), dp(4))
                setOnClickListener {
                    selecionado = if (selecionado == op) "" else op
                    aoEscolher(selecionado)
                    pintar()
                }
            }
            botoes.add(b)
            linha.addView(b, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(8) })
        }
        pintar()
        rolagem.addView(linha)
        caixa.addView(rolagem, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })
        return caixa
    }

    private fun imagem(caminho: String, alturaMax: Int): View? {
        val bmp = carregarFoto(caminho, 900) ?: return null
        return ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            maxHeight = dp(alturaMax)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = fundo(CINZA, 10)
        }
    }

    /** Abre a foto já reduzida e na posição certa (corrige a rotação da câmera). */
    private fun carregarFoto(caminho: String, ladoMax: Int): Bitmap? {
        val f = File(caminho)
        if (!f.exists()) return null
        val limites = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(caminho, limites)
        if (limites.outWidth <= 0 || limites.outHeight <= 0) return null
        var escala = 1
        while (limites.outWidth / (escala * 2) >= ladoMax && limites.outHeight / (escala * 2) >= ladoMax) escala *= 2
        val bmp = BitmapFactory.decodeFile(caminho, BitmapFactory.Options().apply { inSampleSize = escala }) ?: return null
        val graus = try {
            when (ExifInterface(caminho).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) { 0f }
        if (graus == 0f) return bmp
        val m = Matrix().apply { postRotate(graus) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun aviso(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
